package tuke.sk;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

public class PermutationForm {
    private JButton permutationButton;
    private JPanel permutationPanel;
    private JLabel permutationLabel;
    private JSpinner permutationSpinner;
    private JScrollPane scrollPane;
    private JTextArea permutationTextArea;

    private boolean running = false;

    public PermutationForm() {
        permutationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                permutationTextArea.selectAll();
                permutationTextArea.replaceSelection("");
                permutationTextArea.setMargin(new Insets(10, 10, 10, 10));
                    final Task task = new Task();
                    task.addPropertyChangeListener(new PropertyChangeListener() {
                        @Override
                        public void propertyChange(PropertyChangeEvent pce) {
                        }
                    });
                    task.execute();
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Permutation");
        frame.setContentPane(new PermutationForm().permutationPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 500);
        frame.pack();
        frame.setVisible(true);
    }

    void permute(int[] a, int k) {
        if (k == a.length) {
            StringBuilder sb = new StringBuilder();
            sb.append("[");
            for (int i = 0; i < a.length; i++) {
                if (i == a.length - 1) {
                    sb.append(" " + a[i] + " ");
                } else {
                    sb.append(" " + a[i] + ", ");
                }
            }
            sb.append("]" + System.lineSeparator());
            permutationTextArea.append(sb.toString());
        } else {
            for (int i = k; i < a.length; i++) {
                int temp = a[k];
                a[k] = a[i];
                a[i] = temp;
                permute(a, k + 1);
                temp = a[k];
                a[k] = a[i];
                a[i] = temp;
            }
        }
    }

    private class Task extends SwingWorker<Void, Void> {
        @Override
        public Void doInBackground() {
            if (!running) {
                running = true;
                int N = (Integer) permutationSpinner.getValue();
                int[] sequence = new int[N];
                for (int i = 0; i < N; i++) {
                    sequence[i] = i + 1;
                }
                permute(sequence, 0);
                running = false;
            }
            return null;
        }
    }
}
